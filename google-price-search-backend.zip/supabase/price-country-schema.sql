begin;
alter table public.rfq_price_estimates drop constraint rfq_price_estimates_currency_check;
alter table public.rfq_price_estimates add constraint rfq_price_estimates_currency_check check(currency ~ '^[A-Z]{3}$');
alter table public.rfq_price_estimates add column country_code text not null default 'de' check(country_code ~ '^[a-z]{2}$');
alter table public.rfq_price_estimates add column quantity numeric not null default 1 check(quantity>0 and quantity<=1000000);
alter table public.rfq_price_estimates add column line_total numeric(20,2) check(line_total>0);
commit;
