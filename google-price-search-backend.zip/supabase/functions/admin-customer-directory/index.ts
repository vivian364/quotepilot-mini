import {createClient} from 'npm:@supabase/supabase-js@2.57.4';
const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false}});
Deno.serve(async(req:Request)=>{
 const origin=req.headers.get('origin')||'',allowed=['https://marinequo.com','https://www.marinequo.com'];
 const headers={'Access-Control-Allow-Origin':allowed.includes(origin)?origin:allowed[0],'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST,OPTIONS','Vary':'Origin','Cache-Control':'no-store','Content-Type':'application/json'};
 const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers});
 if(origin&&!allowed.includes(origin))return json({error:'Origin not allowed'},403);
 if(req.method==='OPTIONS')return new Response(null,{headers});
 if(req.method!=='POST')return json({error:'Method not allowed'},405);
 const token=(req.headers.get('authorization')||'').replace(/^Bearer /i,'');if(!token)return json({error:'Sign in required'},401);
 const {data:identity,error:authError}=await db.auth.getUser(token);if(authError||!identity.user)return json({error:'Sign in required'},401);
 const {data:admin,error:adminError}=await db.from('admin_users').select('user_id').eq('user_id',identity.user.id).maybeSingle();
 if(adminError||!admin)return json({error:'Administrator access required'},403);
 try{
  const text=await req.text();if(text.length>1024)return json({error:'Request too large'},413);const {page=1}=JSON.parse(text||'{}');if(!Number.isSafeInteger(page)||page<1||page>10000)return json({error:'Invalid page'},400);
  const {data,error}=await db.auth.admin.listUsers({page,perPage:50});if(error)return json({error:'Could not load registrations'},503);
  const users=data.users.filter(u=>!u.is_anonymous);let profiles=[];
  if(users.length){const {data:p,error:e}=await db.from('customer_profiles').select('user_id,company_name,contact_name').in('user_id',users.map(u=>u.id));if(e)return json({error:'Could not load company details'},503);profiles=p||[];}
  const byId=new Map(profiles.map(p=>[p.user_id,p]));
  return json({page,has_more:data.users.length===50,accounts:users.map(u=>{const p=byId.get(u.id);return {id:u.id,email:u.email||'',registered_at:u.created_at,email_confirmed:!!u.email_confirmed_at,company:p?.company_name||'',contact:p?.contact_name||'',profile_complete:!!p?.company_name};})});
 }catch{return json({error:'Could not load registrations'},400);}
});
