import {createClient} from 'npm:@supabase/supabase-js@2.57.4';
import {matchingOffers,publicOffer} from './pricing.mjs';
const secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,db=createClient(Deno.env.get('SUPABASE_URL')!,secret,{auth:{persistSession:false}}),encoder=new TextEncoder();
const apiKey=Deno.env.get('SERPAPI_API_KEY');
const hex=(b:ArrayBuffer)=>Array.from(new Uint8Array(b),v=>v.toString(16).padStart(2,'0')).join('');
const hash=async(s:string)=>hex(await crypto.subtle.digest('SHA-256',encoder.encode(s)));
const hmac=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['verify']);
Deno.serve(async(req:Request)=>{
 const origin=req.headers.get('origin')||'',origins=['https://marinequo.com','https://www.marinequo.com'];
 const headers={'Access-Control-Allow-Origin':origins.includes(origin)?origin:origins[0],'Access-Control-Allow-Headers':'content-type, authorization, apikey','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Vary':'Origin','Cache-Control':'no-store','Content-Type':'application/json'};
 const json=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers});
 if(origin&&!origins.includes(origin))return json({error:'Origin not allowed'},403);
 if(req.method==='OPTIONS')return new Response(null,{headers});
 if(req.method==='GET')return json({configured:!!apiKey});
 if(req.method!=='POST')return json({error:'Method not allowed'},405);
 if(!apiKey)return json({error:'Price search is not connected yet. Please submit your RFQ for review.',code:'SEARCH_NOT_CONFIGURED'},503);
 try{
  const reader=req.body?.getReader();if(!reader)throw Error('Missing request');let size=0;const chunks=[];
  while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>8192){await reader.cancel();return json({error:'Request too large'},413);}chunks.push(value);}
  const bytes=new Uint8Array(size);let at=0;for(const c of chunks){bytes.set(c,at);at+=c.length;}const body=JSON.parse(new TextDecoder().decode(bytes));
  for(const field of ['brand','part'])if(typeof body[field]!=='string'||body[field].trim().length<2||body[field].length>100||/[\r\n<>]/.test(body[field]))throw Error('Enter the manufacturer and exact model or part number.');
  if(body.website)throw Error('Request rejected');
  const sig=String(body.signature||''),challenge=String(body.challenge||'');if(!/^[a-f0-9]{64}$/.test(sig))throw Error('Verification required');
  if(!await crypto.subtle.verify('HMAC',hmac,new Uint8Array(sig.match(/../g)!.map((x:string)=>parseInt(x,16))),encoder.encode(challenge)))throw Error('Invalid verification');
  const c=JSON.parse(atob(challenge)),age=Date.now()-c.at,ip=(req.headers.get('x-forwarded-for')||'unknown').split(',')[0].trim();
  if(c.id!==body.request_id||c.ip!==await hash(secret+':ip:'+ip)||age<1500||age>600000||!Number.isSafeInteger(body.proof)||body.proof<0||!(await hash(challenge+':'+body.proof)).startsWith('000'))throw Error('Verification expired. Please retry.');
  async function limit(key:string,n:number,seconds:number){const {data,error}=await db.rpc('consume_rfq_limit',{p_key:key,p_limit:n,p_seconds:seconds});if(error)throw Error('Search protection unavailable');return data===true;}
  if(!await limit('price-proof:'+await hash(challenge),1,600))return json({error:'Verification already used'},409);
  if(!await limit('price-ip:'+c.ip,5,3600)||!await limit('price-global:'+new Date().toISOString().slice(0,10),100,86400))return json({error:'Search limit reached. Submit your RFQ for review.'},429);
  const {data:settings,error:settingsError}=await db.from('rfq_price_settings').select('markup_percent,enabled').eq('id',1).single();
  if(settingsError||!settings?.enabled)return json({error:'Price search is awaiting activation.',code:'SEARCH_DISABLED'},503);
  const params=new URLSearchParams({engine:'google_shopping',q:body.brand.trim()+' '+body.part.trim(),gl:'de',hl:'en',api_key:apiKey});
  const response=await fetch('https://serpapi.com/search.json?'+params,{signal:AbortSignal.timeout(25000)});
  if(!response.ok)return json({error:'Search provider temporarily unavailable. Please submit an RFQ.'},502);
  const result=await response.json();if(result.error)return json({error:'Search provider could not complete the request.'},502);
  const offers=matchingOffers(result.shopping_results,body.brand,body.part);
  if(!offers.length)return json({status:'price_on_request',message:'No exact product match with a reliable EUR price. Please submit your RFQ.'});
  const best=offers[0],offer=publicOffer(best,Number(settings.markup_percent));
  const {data:audit,error:auditError}=await db.from('rfq_price_estimates').insert({brand:body.brand.trim(),part_number:body.part.trim(),matched_title:best.title,source_name:best.source||null,source_url:best.product_link||best.link,source_price:best.extracted_price,currency:'EUR',markup_percent:settings.markup_percent,selling_price:offer.unit_price}).select('id,created_at').single();
  if(auditError)return json({error:'Could not record the estimate. Please submit your RFQ.'},503);
  return json({status:'estimate',estimate_id:audit.id,checked_at:audit.created_at,...offer});
 }catch(error){return json({error:error instanceof Error?error.message:'Invalid request'},400);}
});
