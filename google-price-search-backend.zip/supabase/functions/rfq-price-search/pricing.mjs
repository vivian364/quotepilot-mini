import {currencyOfPrice,moneyScale,moneyTotal} from './markets.mjs';
export function applyMarkup(cost,percent=15,currency='EUR'){
 if(!Number.isFinite(cost)||cost<=0||!Number.isFinite(percent)||percent<10||percent>15)throw Error('Invalid price or markup');
 const scale=moneyScale(currency),units=Math.round(cost*scale);return Math.ceil(units*(100+percent)/100)/scale;
}
const norm=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'');
const exact=(title,value)=>{const letters=norm(value).split('').join('[^a-z0-9]*');return new RegExp('(^|[^a-z0-9])'+letters+'($|[^a-z0-9])','i').test(title);};
export function matchingOffers(results,brand,part,currency='EUR'){
 const b=norm(brand),p=norm(part);if(b.length<2||p.length<3)throw Error('Brand and exact model/part number are required');
 return (results||[]).filter(r=>{
  const title=norm(r.title);const amount=r.extracted_price;
  return exact(r.title,brand)&&exact(r.title,part)&&!r.second_hand_condition&&!r.installment&&!/compatible|replacement|fits |used|refurbished|renewed|spares? only|for parts|per month|\/mo\b|from /i.test(r.title||'')&&typeof amount==='number'&&Number.isFinite(amount)&&amount>0&&amount<10000000&&currencyOfPrice(r.price,currency)===currency&&typeof(r.product_link||r.link)==='string'&&/^https:\/\//.test(r.product_link||r.link);
 }).sort((a,b)=>a.extracted_price-b.extracted_price);
}
export function publicOffer(row,percent,market={code:'de',name:'Germany',currency:'EUR'},quantity=1){const unit_price=applyMarkup(row.extracted_price,percent,market.currency);return {title:row.title,currency:market.currency,country:market.code,market:market.name,quantity,unit_price,line_total:moneyTotal(unit_price,quantity,market.currency),kind:'indicative',notice:'Local-market listing price per listed unit/package. Taxes, freight, delivery to vessel, compatibility and availability require confirmation.'};}

