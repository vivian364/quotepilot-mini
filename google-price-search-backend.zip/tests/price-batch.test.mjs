import test from 'node:test';import assert from 'node:assert/strict';
import {MARKETS,parsePriceList,currencyOfPrice,moneyTotal,suggestedMarket,safeCsvCell} from '../rfq-price-markets.mjs';
import {applyMarkup,matchingOffers,publicOffer} from '../supabase/functions/rfq-price-search/pricing.mjs';
const row={title:'Schneider Electric A9F74116 MCB',price:'£10.00',extracted_price:10,product_link:'https://example.com/product'};
test('Excel tabs, CSV, semicolons, headers, quoted fields and decimal quantities',()=>{
 assert.deepEqual(parsePriceList('Manufacturer\tPart number\tQuantity\nSchneider\tA9F74116\t2\nDanfoss\tKP35\t3'),[{brand:'Schneider',part:'A9F74116',quantity:2},{brand:'Danfoss',part:'KP35',quantity:3}]);
 assert.equal(parsePriceList('"Schneider, Electric",A9F74116,2')[0].brand,'Schneider, Electric');assert.equal(parsePriceList('Danfoss; KP35; 1,5')[0].quantity,1.5);
});
test('reject too many lines, invalid quantities and malformed lists',()=>{for(const text of [Array(51).fill('Danfoss;KP35;1').join('\n'),'Danfoss KP35 1','Danfoss;KP35;0','Danfoss;KP35;NaN','Danfoss;KP35;-2','"Danfoss;KP35;1'])assert.throws(()=>parsePriceList(text));});
test('country currencies distinguish USD from SGD and CAD from AUD',()=>{
 assert.equal(currencyOfPrice('US$10','SGD'),'USD');assert.equal(currencyOfPrice('S$10','SGD'),'SGD');assert.equal(currencyOfPrice('CA$10','AUD'),'CAD');assert.equal(currencyOfPrice('A$10','AUD'),'AUD');assert.equal(currencyOfPrice('€10','GBP'),'EUR');assert.equal(currencyOfPrice('£10','GBP'),'GBP');assert.equal(currencyOfPrice('$10','SGD'),'SGD');assert.equal(currencyOfPrice('¥100','JPY'),'JPY');
});
test('local prices only, markup, quantity totals and zero-decimal currencies',()=>{
 assert.equal(matchingOffers([row],'Schneider','A9F74116','EUR').length,0);assert.equal(matchingOffers([row],'Schneider','A9F74116','GBP').length,1);
 const offer=publicOffer(row,15,MARKETS.gb,3);assert.equal(offer.unit_price,11.5);assert.equal(offer.line_total,34.5);assert.equal(offer.country,'gb');assert.equal(offer.currency,'GBP');assert.equal('source_price' in offer,false);
 assert.equal(applyMarkup(101,15,'JPY'),117);assert.equal(moneyTotal(11.5,3,'GBP'),34.5);
});
test('ports suggest the correct country; unsupported countries never borrow prices',()=>{assert.equal(suggestedMarket('Port Louis'),'mu');assert.equal(suggestedMarket('Singapore'),'sg');assert.equal(suggestedMarket('Rotterdam'),'nl');assert.equal(MARKETS.mu.supported,false);assert.equal(MARKETS.cn.supported,false);});
test('CSV exports neutralize formula injection',()=>{for(const v of ['=1+1','+SUM(A1)','@test','-10'])assert.ok(safeCsvCell(v).startsWith('"\''));assert.equal(safeCsvCell('normal'),'"normal"');});
