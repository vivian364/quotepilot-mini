MARINE QUO — BY KONTES MARINE

GitHub Pages deployment:
1. In github.com/vivian364/quotepilot-mini open the main branch.
2. Upload the index.html and CNAME files from this ZIP to repository ROOT, replacing index.html and keeping the existing CNAME.
3. Commit changes.
4. Check Settings > Pages, then visit https://kontesmarinequotes.com/ once deployment completes.

This website is a static preview: RFQ creates a mailto email, chat is scripted demo, there are no live accounts or automated binding quotes.
The wave image is embedded in index.html for reliable loading.
