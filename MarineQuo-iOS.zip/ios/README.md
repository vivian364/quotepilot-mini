# MARINE QUO iOS — initial source project

Bundle identifier: `com.marinequo.app` (App Store Connect ID 6827282020).

Uses the production https://marinequo.com interface in WKWebView so the existing site design, RFQs and Vessel Passport remain consistent. Includes native navigation, refresh, share sheet, external-link handling, persistent website sessions and connection errors. The supplied app icon is derived from the existing site asset.

## Build

On a Mac with Xcode and XcodeGen installed:

```
cd ios
xcodegen generate
open MarineQuo.xcodeproj
```

Choose the correct Apple Developer team under Signing & Capabilities. Use a unique build number, run on a real iPhone, then Product > Archive > Distribute App > App Store Connect. Never commit signing certificates, private keys or provisioning profiles.

The included GitHub workflow builds an **unsigned simulator app only**. It does not produce an App Store upload or a signed IPA. Trigger it once repository write access is connected.

## Current verification and remaining work

Source and configuration prepared on Linux; **not compiled or tested on iOS**. macOS/Xcode is required for compilation and signing. No Apple credentials or signing material have been embedded.

Before release, test RFQ submission, multi-file attachments (PDF/Excel/Word/images/ZIP), file downloads, keyboard and safe areas, login/logout/reset, session persistence, account deletion, pop-ups, sharing and offline recovery. In-app account deletion must be implemented in the underlying product if account creation is available. Authentication links must be tested on-device; universal links and OAuth handoff are not yet configured.

This initial WebKit client is not asserted to satisfy Apple's minimum-functionality requirement (4.2). More meaningful iOS-specific utility and complete device QA may be needed before submission. Do not claim App Review readiness based on this scaffold.

App Store metadata still needs actual app screenshots, a verified privacy-policy URL and accurate privacy disclosures, content-rights declaration, review account and contact information, availability/pricing and any account compliance requirements. Only upload screenshots from the finished running app. Approval and publication depend on Apple.
