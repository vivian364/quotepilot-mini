import SwiftUI
import WebKit
import SafariServices

private let home = URL(string: "https://marinequo.com/")!

struct MarineWorkspace: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> WorkspaceController { WorkspaceController() }
    func updateUIViewController(_ controller: WorkspaceController, context: Context) {}
}

final class WorkspaceController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    private var web: WKWebView!
    private let progress = UIProgressView(progressViewStyle: .default)
    private var observation: NSKeyValueObservation?
    private let status = UILabel()
    private var backButton: UIBarButtonItem!
    private var forwardButton: UIBarButtonItem!
    private let navy = UIColor(red: 0.02, green: 0.11, blue: 0.17, alpha: 1)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = navy
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = true
        web.backgroundColor = navy
        let refresh = UIRefreshControl()
        refresh.addTarget(self, action: #selector(reload), for: .valueChanged)
        web.scrollView.refreshControl = refresh
        let toolbar = UIToolbar()
        toolbar.barTintColor = navy
        toolbar.tintColor = .white
        backButton = UIBarButtonItem(image: UIImage(systemName: "chevron.left"), style: .plain, target: self, action: #selector(goBack))
        backButton.accessibilityLabel = "Go back"
        forwardButton = UIBarButtonItem(image: UIImage(systemName: "chevron.right"), style: .plain, target: self, action: #selector(goForward))
        forwardButton.accessibilityLabel = "Go forward"
        let homeButton = UIBarButtonItem(image: UIImage(systemName: "house"), style: .plain, target: self, action: #selector(goHome))
        homeButton.accessibilityLabel = "Marine Quo home"
        let passport = UIBarButtonItem(title: "Passport", style: .plain, target: self, action: #selector(goPassport))
        let share = UIBarButtonItem(barButtonSystemItem: .action, target: self, action: #selector(sharePage(_:)))
        toolbar.items = [backButton, forwardButton, UIBarButtonItem(systemItem: .flexibleSpace), homeButton, UIBarButtonItem(systemItem: .flexibleSpace), passport, UIBarButtonItem(systemItem: .flexibleSpace), share]
        status.textColor = .white
        status.font = .preferredFont(forTextStyle: .footnote)
        status.numberOfLines = 0
        status.textAlignment = .center
        status.isHidden = true
        for item in [web!, progress, toolbar, status] { item.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(item) }
        NSLayoutConstraint.activate([
            progress.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            progress.leadingAnchor.constraint(equalTo: view.leadingAnchor), progress.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            web.topAnchor.constraint(equalTo: progress.bottomAnchor), web.leadingAnchor.constraint(equalTo: view.leadingAnchor), web.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            web.bottomAnchor.constraint(equalTo: toolbar.topAnchor),
            toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor), toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor), toolbar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            status.centerXAnchor.constraint(equalTo: view.centerXAnchor), status.centerYAnchor.constraint(equalTo: view.centerYAnchor), status.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.85)
        ])
        observation = web.observe(\.estimatedProgress, options: [.new]) { [weak self] web, _ in
            self?.progress.progress = Float(web.estimatedProgress)
            self?.progress.isHidden = web.estimatedProgress >= 1
        }
        goHome()
    }

    @objc private func goHome() { web.load(URLRequest(url: home)) }
    @objc private func goPassport() { web.load(URLRequest(url: home.appendingPathComponent("passport.html"))) }
    @objc private func goBack() { web.goBack() }
    @objc private func goForward() { web.goForward() }
    @objc private func reload() { status.isHidden = true; web.reload() }
    @objc private func sharePage(_ sender: UIBarButtonItem) {
        guard let url = web.url, isInternal(url) else { return }
        // Exclude query strings and fragments, which may contain sign-in tokens.
        var safe = URLComponents(url: url, resolvingAgainstBaseURL: false)!
        safe.query = nil; safe.fragment = nil
        guard let shareURL = safe.url else { return }
        let sheet = UIActivityViewController(activityItems: [shareURL], applicationActivities: nil)
        sheet.popoverPresentationController?.barButtonItem = sender
        present(sheet, animated: true)
    }
    private func isInternal(_ url: URL) -> Bool {
        url.scheme == "https" && ["marinequo.com", "www.marinequo.com"].contains(url.host?.lowercased() ?? "")
    }
    private func openExternal(_ url: URL) {
        if url.scheme == "https" || url.scheme == "http" {
            present(SFSafariViewController(url: url), animated: true)
        } else if ["mailto", "tel"].contains(url.scheme ?? ""), UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url)
        }
    }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        if isInternal(url) || url.scheme == "about" || url.scheme == "blob" { decisionHandler(.allow); return }
        decisionHandler(.cancel)
        if action.targetFrame?.isMainFrame != false { openExternal(url) }
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = action.request.url { if isInternal(url) { web.load(URLRequest(url: url)) } else { openExternal(url) } }
        return nil
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { status.isHidden = true }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        status.isHidden = true; web.scrollView.refreshControl?.endRefreshing()
        backButton.isEnabled = web.canGoBack; forwardButton.isEnabled = web.canGoForward
    }
    private func failed(_ error: Error) {
        web.scrollView.refreshControl?.endRefreshing()
        if (error as NSError).code == NSURLErrorCancelled { return }
        status.text = "Unable to connect to MARINE QUO. Check your connection and pull down to retry."
        status.backgroundColor = navy; status.isHidden = false
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { failed(error) }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { failed(error) }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { web.reload() }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let alert = UIAlertController(title: "MARINE QUO", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() }); present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = UIAlertController(title: "MARINE QUO", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) }); present(alert, animated: true)
    }
}
