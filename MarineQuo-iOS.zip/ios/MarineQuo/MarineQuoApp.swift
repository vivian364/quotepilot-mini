import SwiftUI

@main
struct MarineQuoApp: App {
    var body: some Scene {
        WindowGroup { MarineWorkspace().preferredColorScheme(.light) }
    }
}
