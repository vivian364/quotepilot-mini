import test from 'node:test';
import assert from 'node:assert/strict';
import {validateFiles,checkSignature,MAX_FILE} from '../supabase/functions/rfq-submit-v2/validation.mjs';
const f=(name,bytes)=>new File([new Uint8Array(bytes)],name);
test('required formats pass content signatures',async()=>{
 for(const [name,bytes] of [['a.pdf',[37,80,68,70,45]],['a.doc',[208,207,17,224,161,177,26,225]],['a.xls',[208,207,17,224,161,177,26,225]],['a.docx',[80,75,3,4]],['a.xlsx',[80,75,3,4]],['a.zip',[80,75,5,6]],['a.jpg',[255,216,255]],['a.png',[137,80,78,71,13,10,26,10]],['a.csv',[97,44,98,10]]]){const file=f(name,bytes);validateFiles([file]);assert.ok(await checkSignature(file));}
});
test('reject executable, empty, oversize, count and total',()=>{
 for(const files of [[f('a.exe',[1])],[f('a.pdf',[])],[{name:'a.pdf',size:MAX_FILE+1}],Array(6).fill({name:'a.pdf',size:1}),Array(2).fill({name:'a.pdf',size:MAX_FILE})])assert.throws(()=>validateFiles(files));
});
test('reject renamed HTML and mismatched binary',async()=>{
 await assert.rejects(()=>checkSignature(new File(['<script>alert(1)</script>'],'a.pdf')));
 await assert.rejects(()=>checkSignature(new File(['<html>test</html>'],'a.csv')));
 assert.throws(()=>validateFiles([f('../a.pdf',[1])]));
});
