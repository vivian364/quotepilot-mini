import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false}});
Deno.serve(async(req:Request)=>{
 const origin=req.headers.get('origin')||'',allowed=['https://marinequo.com','https://www.marinequo.com'];
 const headers={'Access-Control-Allow-Origin':allowed.includes(origin)?origin:allowed[0],'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json','Vary':'Origin','Cache-Control':'no-store'};
 const json=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers});
 if(origin&&!allowed.includes(origin))return json({error:'Origin not allowed'},403);
 if(req.method==='OPTIONS')return new Response(null,{headers});
 if(req.method!=='POST')return json({error:'Method not allowed'},405);
 try{
  const {data:session,error}=await db.auth.getUser((req.headers.get('authorization')||'').replace(/^Bearer /i,''));
  if(error||!session.user)return json({error:'Use the secure Instant Quotation form or sign in to Vessel Passport.'},401);
  const body=await req.json();const id=body.quotation_id;
  if(typeof id!=='string'||id.length!==36)return json({error:'Invalid request'},400);
  const {data:q}=await db.from('quotations').select('id,customer_id,product_description,delivery_port,quantity,vessel_id').eq('id',id).maybeSingle();
  if(!q||q.customer_id!==session.user.id)return json({error:'Request not found'},403);
  const {data:allowedSend,error:rateError}=await db.rpc('consume_rfq_limit',{p_key:'notify:'+id,p_limit:3,p_seconds:86400});
  if(rateError||!allowedSend)return json({error:'Notification limit reached'},429);
  const {data:profile}=await db.from('customer_profiles').select('company_name,contact_name').eq('user_id',session.user.id).maybeSingle();
  const {data:vessel}=await db.from('vessels').select('vessel_name,imo_number').eq('id',q.vessel_id).maybeSingle();
  const {data:files}=await db.from('rfq_attachments').select('storage_path,filename').eq('quotation_id',id);
  const links=[];for(const file of files||[]){const {data}=await db.storage.from('marine-rfq-attachments').createSignedUrl(file.storage_path,86400,{download:true});if(data)links.push(file.filename+': '+data.signedUrl);}
  const key=Deno.env.get('RESEND_API_KEY');if(!key)return json({error:'Email unavailable; request remains saved.'},503);
  const text=`Vessel Passport RFQ ${id}\nCompany: ${profile?.company_name||'-'}\nContact: ${profile?.contact_name||'-'}\nEmail: ${session.user.email}\nVessel: ${vessel?.vessel_name||'-'}\nIMO: ${vessel?.imo_number||'-'}\nPort: ${q.delivery_port}\nQuantity: ${q.quantity}\nRequirements: ${q.product_description}\nAttachments (links expire in 24 hours):\n${links.join('\n')||'None'}\nFiles are customer supplied. Scan before opening.`;
  const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json','Idempotency-Key':'portal-'+id},body:JSON.stringify({from:'MARINE QUO <quotes@marinequo.com>',to:['info@kontesmarine.com'],reply_to:session.user.email,subject:'New Marine RFQ - MARINE QUO',text})});
  return response.ok?json({success:true}):json({error:'Email could not be confirmed; request remains saved.'},502);
 }catch{return json({error:'Invalid request'},400);}
});
