import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import { validateFiles, checkSignature, MAX_TOTAL } from './validation.mjs';
const bucket='marine-rfq-attachments';
const url=Deno.env.get('SUPABASE_URL')!, secret=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const db=createClient(url,secret,{auth:{persistSession:false,autoRefreshToken:false}});
const enc=new TextEncoder();
const hex=(b:ArrayBuffer)=>Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('');
const hash=async(s:string)=>hex(await crypto.subtle.digest('SHA-256',enc.encode(s)));
const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
async function limit(key:string,n:number,seconds:number){const {data,error}=await db.rpc('consume_rfq_limit',{p_key:key,p_limit:n,p_seconds:seconds});if(error)throw Error('Request protection unavailable. Please retry later.');return data===true;}
Deno.serve(async(req:Request)=>{
 const origin=req.headers.get('origin')||'';
 const allowed=['https://marinequo.com','https://www.marinequo.com'];
 const cors={'Access-Control-Allow-Origin':allowed.includes(origin)?origin:allowed[0],'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Vary':'Origin'};
 const json=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers:{...cors,'Content-Type':'application/json','Cache-Control':'no-store'}});
 if(origin&&!allowed.includes(origin))return json({error:'Origin not allowed'},403);
 if(req.method==='OPTIONS')return new Response(null,{headers:cors});
 if(req.method!=='POST')return json({error:'Method not allowed'},405);
 try{
  const ip=(req.headers.get('x-forwarded-for')||'unknown').split(',')[0].trim();
  const ipHash=await hash(secret+':ip:'+ip);
  if((req.headers.get('content-type')||'').includes('application/json')){
   const raw=await req.text();if(raw.length>1000)return json({error:'Request too large'},413);
   const input=JSON.parse(raw);
   if(input.action!=='challenge'||!uuid.test(input.request_id))return json({error:'Use the secure RFQ form.'},400);
   if(!await limit('challenge:'+ipHash,60,3600))return json({error:'Too many attempts. Please try later.'},429);
   const challenge=btoa(JSON.stringify({id:input.request_id,ip:ipHash,at:Date.now(),nonce:crypto.randomUUID()}));
   const signature=hex(await crypto.subtle.sign('HMAC',key,enc.encode(challenge)));
   return json({challenge,signature,difficulty:3});
  }
  if(!await limit('attempt:'+ipHash,30,3600))return json({error:'Too many attempts. Please try later.'},429);
  // Read with a hard streaming bound even when Content-Length is missing or forged.
  const reader=req.body?.getReader();if(!reader)return json({error:'Missing request'},400);
  const chunks:Uint8Array[]=[];let size=0;
  while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX_TOTAL+65536){await reader.cancel();return json({error:'Maximum 20 MB total.'},413);}chunks.push(value);}
  const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}
  const form=await new Response(bytes,{headers:{'Content-Type':req.headers.get('content-type')||''}}).formData();
  const meta=JSON.parse(String(form.get('payload')||'{}'));
  const files=form.getAll('files');if(files.some(f=>!(f instanceof File)))throw Error('Invalid file');
  validateFiles(files);const types=await Promise.all((files as File[]).map(checkSignature));
  const id=meta.request_id;if(!uuid.test(id))throw Error('Invalid request ID');
  let owner:string|null=null,quote:string|null=null,guest:string|null=null;
  if(meta.quotation_id){
   const token=(req.headers.get('authorization')||'').replace(/^Bearer /i,'');
   const {data:user,error}=await db.auth.getUser(token);if(error||!user.user)return json({error:'Please sign in again.'},401);
   owner=user.user.id;quote=meta.quotation_id;
   const {data:q}=await db.from('quotations').select('id,customer_id,status').eq('id',quote).maybeSingle();
   if(!q||q.customer_id!==owner||q.status!=='pending')return json({error:'Cannot attach to this request.'},403);
   const {data:existing,error:countError}=await db.from('rfq_attachments').select('storage_path,size_bytes').eq('quotation_id',quote);
   if(countError)throw Error('Could not check attachments');
   if(existing?.some(x=>x.storage_path.startsWith(`${owner}/${quote}/${id}-`)))return json({success:true,request_id:quote,duplicate:true});
   if(!await limit('batch:'+quote,1,60))return json({error:'An upload is already in progress. Retry in one minute.'},429);
   if((existing?.length||0)+files.length>5)throw Error('Maximum 5 attachments per RFQ.');
   if((existing||[]).reduce((n,x)=>n+Number(x.size_bytes),0)+files.reduce((n,f)=>n+(f as File).size,0)>MAX_TOTAL)throw Error('Maximum 20 MB attachments per RFQ.');
   if(!await limit('account:'+owner,30,3600))return json({error:'Upload limit reached. Please try later.'},429);
  }else{
   if(meta.website)throw Error('Request rejected');
   const challenge=String(meta.challenge||''),sig=String(meta.signature||'');
   if(!/^[a-f0-9]{64}$/.test(sig))return json({error:'Please verify the request again.'},400);
   const signature=new Uint8Array(sig.match(/../g)!.map((s:string)=>parseInt(s,16)));
   if(!await crypto.subtle.verify('HMAC',key,signature,enc.encode(challenge)))throw Error('Invalid verification');
   const c=JSON.parse(atob(challenge)),age=Date.now()-c.at;
   if(c.id!==id||c.ip!==ipHash||age<1500||age>600000||!Number.isSafeInteger(meta.proof)||meta.proof<0||!(await hash(challenge+':'+meta.proof)).startsWith('000'))throw Error('Verification expired. Please retry.');
   for(const f of ['company','email','delivery_port','product','vessel']){if(typeof meta[f]!=='string'||meta[f].length>2000)throw Error('Invalid field: '+f);meta[f]=meta[f].trim();}
   if(!meta.company||!meta.delivery_port||!meta.product||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(meta.email))throw Error('Company, email, port and requirements are required.');
   if(!await limit('proof:'+await hash(challenge),1,600))return json({error:'Verification already used. Please retry.'},409);
   if(!await limit('submit:'+ipHash,10,3600)||!await limit('email:'+await hash(meta.email.toLowerCase()),5,3600))return json({error:'Submission limit reached. Please try later.'},429);
   guest=id;
   const {error}=await db.from('guest_rfqs').insert({id,company:meta.company,email:meta.email,vessel:meta.vessel,delivery_port:meta.delivery_port,product_description:meta.product});
   if(error){if(error.code==='23505')return json({success:true,request_id:id,duplicate:true});throw Error('Could not save your request.');}
  }
  const paths:string[]=[];
  try{
   const rows=[];
   for(let i=0;i<files.length;i++){
    const f=files[i] as File;
    const safe=f.name.replace(/[^A-Za-z0-9._-]/g,'_');
    const path=`${owner||'guest'}/${quote||guest}/${id}-${i}-${safe}`;
    const {error}=await db.storage.from(bucket).upload(path,f,{contentType:types[i],upsert:false});if(error)throw Error('Upload failed. Please retry.');paths.push(path);
    rows.push({quotation_id:quote,owner_id:owner,guest_request_id:guest,storage_path:path,filename:f.name,content_type:types[i],size_bytes:f.size});
   }
   if(rows.length){const {error}=await db.from('rfq_attachments').insert(rows);if(error){console.error('attachment metadata',JSON.stringify(error));throw Error('Could not save attachment details.');}}
  }catch(error){
   if(paths.length)await db.storage.from(bucket).remove(paths);
   if(guest)await db.from('guest_rfqs').delete().eq('id',guest);
   throw error;
  }
  if(guest){
   const apiKey=Deno.env.get('RESEND_API_KEY');let sent=false;
   if(apiKey){
    const links=[];for(const path of paths){const {data}=await db.storage.from(bucket).createSignedUrl(path,86400,{download:true});if(data)links.push(data.signedUrl);}
    const text=`New quotation request ${id}\nCompany: ${meta.company}\nEmail: ${meta.email}\nVessel: ${meta.vessel}\nDelivery port: ${meta.delivery_port}\nRequirements: ${meta.product}\n\nAttachments (private download links expire in 24 hours):\n${links.join('\n')||'None'}\nFiles are customer supplied. Scan before opening.`;
    try{const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json','Idempotency-Key':id},body:JSON.stringify({from:'MARINE QUO <quotes@marinequo.com>',to:['info@kontesmarine.com'],reply_to:meta.email,subject:'New Marine RFQ - MARINE QUO',text})});sent=r.ok;}catch{sent=false;}
   }
   if(sent)await db.from('guest_rfqs').update({notification_sent:true}).eq('id',id);
   return json({success:true,request_id:id,notification_sent:sent});
  }
  return json({success:true,request_id:quote,attachment_count:paths.length});
 }catch(error){console.error('RFQ upload:',error instanceof Error?error.message:'failed');return json({error:error instanceof Error?error.message:'Invalid request'},400);}
});
