export const MAX_FILE=15*1024*1024, MAX_TOTAL=20*1024*1024, MAX_FILES=5;
export const MIME={pdf:'application/pdf',doc:'application/msword',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',xls:'application/vnd.ms-excel',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',csv:'text/csv',jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif',zip:'application/zip'};
export function validateFiles(files){
 if(files.length>MAX_FILES)throw Error('Maximum 5 files per request.');
 if(files.reduce((n,f)=>n+f.size,0)>MAX_TOTAL)throw Error('Maximum 20 MB total.');
 for(const f of files){const ext=f.name.split('.').pop().toLowerCase();if(!MIME[ext]||f.name.length>180||/[\x00-\x1f/\\]/.test(f.name))throw Error('Unsupported filename or file type.');if(!f.size||f.size>MAX_FILE)throw Error('Each file must be between 1 byte and 15 MB.');}
}
export async function checkSignature(file){
 const ext=file.name.split('.').pop().toLowerCase(), b=new Uint8Array(await file.slice(0,512).arrayBuffer());
 const starts=(a)=>a.every((v,i)=>b[i]===v);let valid=false;
 if(ext==='pdf')valid=starts([37,80,68,70,45]);
 if(['doc','xls'].includes(ext))valid=starts([208,207,17,224,161,177,26,225]);
 if(['docx','xlsx','zip'].includes(ext))valid=starts([80,75,3,4])||starts([80,75,5,6]);
 if(['jpg','jpeg'].includes(ext))valid=starts([255,216,255]);
 if(ext==='png')valid=starts([137,80,78,71,13,10,26,10]);
 if(ext==='gif')valid=starts([71,73,70,56]);
 if(ext==='webp')valid=starts([82,73,70,70])&&String.fromCharCode(...b.slice(8,12))==='WEBP';
 if(ext==='csv')valid=!b.includes(0)&&!/^\s*<(?:!doctype|html|script|svg)/i.test(new TextDecoder().decode(b));
 if(!valid)throw Error('File contents do not match the extension: '+file.name);
 return MIME[ext];
}
