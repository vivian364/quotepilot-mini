import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
"Access-Control-Allow-Origin": "https://marinequo.com",
"Access-Control-Allow-Headers":
"authorization, x-client-info, apikey, content-type",
"Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
if (req.method === "OPTIONS") {
return new Response(null, { headers: corsHeaders });
}

const json = (data: unknown, status = 200) =>
new Response(JSON.stringify(data), {
status,
headers: {
...corsHeaders,
"Content-Type": "application/json",
},
});

if (req.method !== "POST") {
return json({ error: "Method not allowed" }, 405);
}

try {
const apiKey = Deno.env.get("RESEND_API_KEY");

if (!apiKey) {
return json({ error: "Email service not configured" }, 500);
}

const body = await req.json();

const fields = [
"company",
"name",
"email",
"vessel",
"imo",
"product",
"quantity",
"delivery_port",
"message",
] as const;

const data: Record<string, string> = {};

for (const field of fields) {
const value = body[field];

if (value !== undefined && typeof value !== "string") {
return json({ error: `Invalid field: ${field}` }, 400);
}

data[field] = (value || "").trim();

if (data[field].length > 2000) {
return json({ error: `Field too long: ${field}` }, 400);
}
}

if (
!data.name ||
!data.email ||
!data.product ||
!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)
) {
return json(
{ error: "Name, valid email and product are required" },
400
);
}

const labels: Record<string, string> = {
company: "Company",
name: "Contact",
email: "Email",
vessel: "Vessel",
imo: "IMO",
product: "Requested products",
quantity: "Quantity",
delivery_port: "Delivery port",
message: "Additional details",
};

const details = fields
.map((field) => `${labels[field]}: ${data[field] || "-"}`)
.join("\n");

const response = await fetch("https://api.resend.com/emails", {
method: "POST",
headers: {
Authorization: `Bearer ${apiKey}`,
"Content-Type": "application/json",
},
body: JSON.stringify({
from: "MARINE QUO <quotes@marinequo.com>",
to: ["info@kontesmarine.com"],
reply_to: data.email,
subject: "New Marine RFQ - MARINE QUO",
text: `New quotation request\n\n${details}`,
}),
});

if (!response.ok) {
console.error("Resend delivery failed", response.status);
return json({ error: "Unable to send RFQ" }, 502);
}

return json({
success: true,
message: "Your RFQ has been submitted successfully.",
});
} catch (error) {
console.error("RFQ error", error);
return json({ error: "Invalid request" }, 400);
}
});
