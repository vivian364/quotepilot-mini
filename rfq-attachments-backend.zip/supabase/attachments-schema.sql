begin;
create table public.guest_rfqs (
 id uuid primary key, company text not null, email text not null, vessel text,
 delivery_port text not null, product_description text not null,
 notification_sent boolean not null default false, created_at timestamptz not null default now()
);
alter table public.guest_rfqs enable row level security;
revoke all on public.guest_rfqs from anon, authenticated;
grant select on public.guest_rfqs to authenticated;
grant all on public.guest_rfqs to service_role;
create policy "Marine admin guest requests" on public.guest_rfqs for select to authenticated using (public.is_marine_admin());
alter table public.rfq_attachments alter column quotation_id drop not null;
alter table public.rfq_attachments alter column owner_id drop not null;
alter table public.rfq_attachments add column guest_request_id uuid references public.guest_rfqs(id);
alter table public.rfq_attachments add constraint attachment_request_scope check (
 (quotation_id is not null and owner_id is not null and guest_request_id is null) or
 (quotation_id is null and owner_id is null and guest_request_id is not null)
);
create index rfq_attachments_guest_request_idx on public.rfq_attachments(guest_request_id);
create index rfq_attachments_quotation_idx on public.rfq_attachments(quotation_id);
create table public.rfq_upload_limits (key text primary key, hits integer not null, expires_at timestamptz not null);
alter table public.rfq_upload_limits enable row level security;
revoke all on public.rfq_upload_limits from anon, authenticated;
grant all on public.rfq_upload_limits to service_role;
create function public.consume_rfq_limit(p_key text, p_limit integer, p_seconds integer) returns boolean
language sql security invoker set search_path='' as $$
 with hit as (
 insert into public.rfq_upload_limits(key,hits,expires_at) values(p_key,1,now()+make_interval(secs=>p_seconds))
 on conflict(key) do update set hits=case when rfq_upload_limits.expires_at<now() then 1 else rfq_upload_limits.hits+1 end,
 expires_at=case when rfq_upload_limits.expires_at<now() then now()+make_interval(secs=>p_seconds) else rfq_upload_limits.expires_at end
 returning hits) select hits<=p_limit from hit;
$$;
revoke all on function public.consume_rfq_limit(text,integer,integer) from public,anon,authenticated;
grant execute on function public.consume_rfq_limit(text,integer,integer) to service_role;
-- Guests cannot directly write to either Storage or attachment metadata.
create policy "Marine admin guest attachment downloads" on storage.objects for select to authenticated
 using(bucket_id='marine-rfq-attachments' and (storage.foldername(name))[1]='guest' and public.is_marine_admin());
commit;

-- Follow-up migrations applied after verifying existing API grants.
drop policy if exists "RFQ private uploads" on storage.objects;
drop policy if exists "RFQ attachments customer add" on public.rfq_attachments;
revoke all on public.rfq_attachments from anon, authenticated;
grant select on public.rfq_attachments to authenticated;
grant all on public.rfq_attachments to service_role;
